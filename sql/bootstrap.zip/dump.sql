-- Test user :
-- Username: test
-- Email: test@test.test
-- Password: testtest

INSERT INTO public.users (id, email, username, password_hash, totp_secret, created_at) VALUES
('a9fd34f8-9917-4f70-88c9-d6ad276463d3', 'test@test.test', 'test', '$2b$10$k4y0Gn/gfHeWyhpzI7hba.pJMNcZqibUln2p6pY1AHM5QEpPW04CK', NULL, '2025-11-21 08:42:46.715068');

INSERT INTO public.clothing_item (id, user_id, name, type, color) VALUES
('6eac116a-fc20-4229-aa4b-7aec8c52c0b6', 'a9fd34f8-9917-4f70-88c9-d6ad276463d3', 'Black shirt', 'shirt', 'black'),
('6ac8b8a3-2f3b-41a4-a54e-2270a94b010f', 'a9fd34f8-9917-4f70-88c9-d6ad276463d3', 'Blue shirt', 'shirt', 'blue'),
('eb7ac92e-9e2a-4839-938c-5f44fc5428ad', 'a9fd34f8-9917-4f70-88c9-d6ad276463d3', 'White boxy shirt', 'shirt', 'white'),
('985b0ca5-2cdc-4abe-971c-9271af767b81', 'a9fd34f8-9917-4f70-88c9-d6ad276463d3', 'Blue long sleeve shirt', 'shirt', 'blue'),

('03f18ad7-e52f-4bdb-8f04-04b094eb987c', 'a9fd34f8-9917-4f70-88c9-d6ad276463d3', 'Black shoes', 'shoes', 'black'),
('ca727857-1425-4643-9cb6-f666f60d9321', 'a9fd34f8-9917-4f70-88c9-d6ad276463d3', 'White shoes', 'shoes', 'white'),
('dbb24210-100c-446a-bf13-b317e043b0f4', 'a9fd34f8-9917-4f70-88c9-d6ad276463d3', 'Boots', 'shoes', 'yellow'),

('d432cda3-b385-48bf-9073-8c1ca60d3d38', 'a9fd34f8-9917-4f70-88c9-d6ad276463d3', 'Red sweater', 'sweater', 'red'),
('45efc73a-03d8-46a8-a476-dbac6b515b6a', 'a9fd34f8-9917-4f70-88c9-d6ad276463d3', 'Brown sweater', 'sweater', 'brown'),
('20da05b1-ecca-41d0-a0a3-7c838becdd69', 'a9fd34f8-9917-4f70-88c9-d6ad276463d3', 'Black sweater', 'sweater', 'black'),
('95806fba-b9bb-4259-8d3d-70ee2517ff91', 'a9fd34f8-9917-4f70-88c9-d6ad276463d3', 'Gray sweater', 'sweater', 'gray'),
('30fd6c47-3046-4ec4-8d62-cb15b896e487', 'a9fd34f8-9917-4f70-88c9-d6ad276463d3', 'Striped green pullover', 'sweater', 'green'),
('b20f86db-2584-4264-ae19-e22a8c93095c', 'a9fd34f8-9917-4f70-88c9-d6ad276463d3', 'Yellow pullover', 'sweater', 'yellow'),

('8e1d617e-3639-44a5-8ea8-88d0751d5058', 'a9fd34f8-9917-4f70-88c9-d6ad276463d3', 'Blue jeans', 'pants', 'blue'),
('730aac07-983c-4ece-99f0-9775d425abd4', 'a9fd34f8-9917-4f70-88c9-d6ad276463d3', 'Black pants', 'pants', 'black'),
('6e901b26-d6e6-499d-860c-c67afd533b79', 'a9fd34f8-9917-4f70-88c9-d6ad276463d3', 'Gray sweater pants', 'pants', 'gray'),
('5fe3f5c9-923b-447b-bb30-df39f665cb42', 'a9fd34f8-9917-4f70-88c9-d6ad276463d3', 'Purple sweater pants', 'pants', 'purple'),

('1245574f-606f-4f8a-ab1e-554b7c646964', 'a9fd34f8-9917-4f70-88c9-d6ad276463d3', 'Brown puffer', 'jacket', 'brown'),
('765b168c-c84d-4aea-bbb9-9b2ac0a1f901', 'a9fd34f8-9917-4f70-88c9-d6ad276463d3', 'Black leather jacket', 'jacket', 'black'),
('34192650-280b-4472-a031-216c7bd324e1', 'a9fd34f8-9917-4f70-88c9-d6ad276463d3', 'Black leather jacket', 'jacket', 'black'),
('875e1ec1-602e-4c89-9556-56dccb846baa', 'a9fd34f8-9917-4f70-88c9-d6ad276463d3', 'Blue denim jacket', 'jacket', 'blue'),
('2d61f298-d5f4-4cad-921c-b486ed426d4a', 'a9fd34f8-9917-4f70-88c9-d6ad276463d3', 'Dark denim jacket', 'jacket', 'black');
